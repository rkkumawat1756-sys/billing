    <footer class="footer">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12 footer-copyright d-flex flex-wrap align-items-center justify-content-between">
            <p class="mb-0 f-w-600">Copyright <span class="year-update"> </span> © <a href="http://rukmanisoftware.com/" target="_blank">Rukmani Software</a> All rights reserved.  </p>
            <p class="mb-0 f-w-600">Version 1.0.1</p>
          </div>
        </div>
      </div>
    </footer>
      <?php /**PATH /home/rusoftonline/public_html/ecomm/resources/views/layout/footer.blade.php ENDPATH**/ ?>