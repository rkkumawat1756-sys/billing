<?php $__env->startSection('title'); ?><?php echo e('Settings'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('admins'); ?>
<div class="card card-orange-outline">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h4 class="mb-0">Setting</h4>
    </div>

    <form action="<?php echo e(route('settings')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <div class="row">
                <!-- Name -->
                <div class="col-md-3 mb-2">
                    <label for="name">Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e(old('name', $setting->name ?? '')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Title -->
                <div class="col-md-3 mb-2">
                    <label for="title">Title</label>
                    <input type="text" name="title" id="title" class="form-control" value="<?php echo e(old('title', $setting->title ?? '')); ?>" placeholder="Title">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Mobile -->
                <div class="col-md-3 mb-2">
                    <label for="mobile">Mobile</label>
                    <input type="text" name="mobile" id="mobile" class="form-control" value="<?php echo e(old('mobile', $setting->mobile ?? '')); ?>" placeholder="Mobile Number">
                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Email -->
                <div class="col-md-3 mb-2">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email', $setting->email ?? '')); ?>" placeholder="example@gmail.com">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Address -->
                <div class="col-md-3 mb-2">
                    <label for="address">Address</label>
                    <input type="text" name="address" id="address" class="form-control" value="<?php echo e(old('address', $setting->address ?? '')); ?>" placeholder="Address">
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Logo Upload -->
                <div class="col-md-3 mb-2">
                    <label for="logo">Logo</label>
                    <input type="file" class="form-control" name="logo" id="logo" accept="image/png, image/jpg, image/jpeg">
                    <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Logo Preview -->
                <div class="col-md-1 mb-2">
                    <img id="previewImage_logo"
                         src="<?php echo e(asset($setting->logo ?? 'schoolimage/default/user_image.jpg')); ?>"
                         width="60px" height="60px"
                         onerror="this.src='<?php echo e(asset('schoolimage/default/user_image.jpg')); ?>'">
                </div>

                <!-- Background Image -->
                <div class="col-md-3 mb-2">
                    <label for="background_image">Favicon Image</label>
                    <input type="file" class="form-control" name="background_image" id="background_image" accept="image/png, image/jpg, image/jpeg">
                    <?php $__errorArgs = ['background_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Background Image Preview -->
                <div class="col-md-1 mb-2">
                    <img id="previewImage_background_image"
                         src="<?php echo e(asset($setting->background_image ?? 'schoolimage/default/user_image.jpg')); ?>"
                         width="60px" height="60px"
                         onerror="this.src='<?php echo e(asset('schoolimage/default/user_image.jpg')); ?>'">
                </div>
            </div>
        </div>

        <div class="card-footer text-center">
            <button type="submit" class="btn btn-secondary">Save</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rusoftonline/public_html/ecomm/resources/views/setting/add.blade.php ENDPATH**/ ?>