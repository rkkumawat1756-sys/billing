
<?php $__env->startSection('title'); ?><?php echo e(('Dashboard')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('admins'); ?>
     
            <div class="row">
        
            
            
              </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rusoftonline/public_html/ecomm/resources/views/index.blade.php ENDPATH**/ ?>