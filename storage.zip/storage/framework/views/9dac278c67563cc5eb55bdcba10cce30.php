
<?php $__env->startSection('title'); ?> Sub Categories <?php $__env->stopSection(); ?>

<?php $__env->startSection('admins'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card card-orange-outline">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4>Sub Categories</h4>
                <a href="<?php echo e(route('subcategories.add')); ?>" class="btn btn-sm btn-primary">+ Add Sub Category</a>
            </div>

            <div class="card-body table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>SR</th>
                            <th>Category Name</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>URL Key</th>
                            <th>Icon</th>
                            <th>Desktop</th>
                            <th>Mobile</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($category->parent->name ?? 'N/A'); ?></td>
                            <td><?php echo e($category->name); ?></td>
                            <td><?php echo e($category->description); ?></td>
                            <td><?php echo e($category->url_key); ?></td>
                            <td><?php if($category->icon): ?><img src="<?php echo e(asset('uploads/category/'.$category->icon)); ?>" width="40"><?php else: ?> N/A <?php endif; ?></td>
                            <td><?php if($category->desktop_image): ?><img src="<?php echo e(asset('uploads/category/'.$category->desktop_image)); ?>" width="40"><?php else: ?> N/A <?php endif; ?></td>
                            <td><?php if($category->mobile_image): ?><img src="<?php echo e(asset('uploads/category/'.$category->mobile_image)); ?>" width="40"><?php else: ?> N/A <?php endif; ?></td>
                            <td>
                                <?php if($category->status): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('subcategories.add', $category->id)); ?>" ><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="rgba(0,0,0,1)" viewBox="0 0 24 24"> <path d="M16.7574 2.99678L9.29145 10.4627L9.29886 14.7099L13.537 14.7024L21 7.23943V19.9968C21 20.5491 20.5523 20.9968 20 20.9968H4C3.44772 20.9968 3 20.5491 3 19.9968V3.99678C3 3.4445 3.44772 2.99678 4 2.99678H16.7574ZM20.4853 2.09729L21.8995 3.5115L12.7071 12.7039L11.2954 12.7064L11.2929 11.2897L20.4853 2.09729Z"></path> </svg></a>
                                <a href="<?php echo e(route('sub.category.delete', $category->id)); ?>" onclick="return confirm('Are you sure?')"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="rgba(243,25,25,1)"> <path d="M4 8H20V21C20 21.5523 19.5523 22 19 22H5C4.44772 22 4 21.5523 4 21V8ZM7 5V3C7 2.44772 7.44772 2 8 2H16C16.5523 2 17 2.44772 17 3V5H22V7H2V5H7ZM9 4V5H15V4H9ZM9 12V18H11V12H9ZM13 12V18H15V12H13Z"></path> </svg></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u362181836/domains/schoolsathi.org/public_html/r/ecom/resources/views/project_management/subcategories.blade.php ENDPATH**/ ?>