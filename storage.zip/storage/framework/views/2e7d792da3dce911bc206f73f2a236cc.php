
        <div class="sidebar-wrapper" data-layout="stroke-svg">
          <div>
            <div class="logo-wrapper"><a href="/">
             <img class="for-light" src="<?php echo e(asset(getSettingValue('logo', 'assets/images/logdo.png'))); ?>" alt="Logo">
</a>
              <div class="back-btn"><i class="fa fa-angle-left"></i></div>
              <div class="toggle-sidebar">
                <svg class="stroke-icon sidebar-toggle status_toggle middle">
                  <use href="<?php echo e(asset('assets/images/icon-sprite.svg#toggle-icon')); ?>"></use>
                </svg>
                <svg class="fill-icon sidebar-toggle status_toggle middle">
                  <use href="<?php echo e(asset('assets/images/icon-sprite.svg#fill-toggle-icon')); ?>"></use>
                </svg>
              </div>
            </div>
            <div class="logo-icon-wrapper"><a href="/"><img class="img-fluid" src="<?php echo e(asset(getSettingValue('logo', 'assets/images/logdo.png'))); ?>" style="width: 30px;" alt=""></a></div>
            <nav class="sidebar-main">
              <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
              <div id="sidebar-menu">
                <?php
                    $permissions = auth()->user()->role->permissions;
                    $sidebars = getSidebarData(0, $permissions);
                ?>
                
                <ul class="sidebar-links" id="simple-bar" style="padding-bottom: 20px;">
                  <li class="back-btn"><a href="/"><img class="img-fluid" src="<?php echo e(asset('assets/images/logo-icon.png')); ?>" alt=""></a>
                    <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
                  </li>
                  <?php $__currentLoopData = $sidebars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="sidebar-list">
                          
                          <a class="sidebar-link <?php echo e(count($sidebar['children']) ? 'sidebar-title' : ''); ?>" href="<?php echo e($sidebar['url'] ? url($sidebar['url']) : 'javascript:void(0)'); ?>">
                            <?php if($sidebar['icons']): ?>
                              <i class="fa <?php echo e($sidebar['icons']); ?>"></i>
                            <?php endif; ?>
                          <span><?php echo e($sidebar['name']); ?></span>
                              <?php if(count($sidebar['children'])): ?>
                                  <span class="sub-arrow"><i class="fa fa-angle-right"></i></span>
                              <?php endif; ?>
                          </a>

                          <?php if(count($sidebar['children'])): ?>
                              <ul class="sidebar-submenu">
                                  <?php $__currentLoopData = $sidebar['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <li>
                                          <a class="<?php echo e(count($child['children']) ? 'submenu-title' : ''); ?>" href="<?php echo e($child['url'] ? url($child['url']) : 'javascript:void(0)'); ?>">
                                              <?php echo e($child['name']); ?>

                                              <?php if(count($child['children'])): ?>
                                                  <span class="sub-arrow"><i class="fa fa-angle-right"></i></span>
                                              <?php endif; ?>
                                          </a>

                                          <?php if(count($child['children'])): ?>
                                              <ul class="nav-sub-childmenu submenu-content">
                                                  <?php $__currentLoopData = $child['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <li><a href="<?php echo e($subchild['url'] ? url($subchild['url']) : 'javascript:void(0)'); ?>"><?php echo e($subchild['name']); ?></a></li>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </ul>
                                          <?php endif; ?>
                                      </li>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                          <?php endif; ?>
                      </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
              
            </nav>
          </div>
        </div><?php /**PATH /home/u362181836/domains/schoolsathi.org/public_html/r/ecom/resources/views/layout/sidebar.blade.php ENDPATH**/ ?>