
<?php $__env->startSection('title'); ?><?php echo e(('Create Category')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('admins'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card card-orange-outline">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4><?php echo e(isset($editData) ? 'Edit Category' : 'Create Category'); ?></h4>
                                    <a href="<?php echo e(route('categories')); ?>" class="btn btn-secondary"> List</a>

            </div>
            <form action="<?php echo e(route('categories.add', $editData->id ?? '')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body row">

                    
                    <div class="col-md-12 mb-2">
                        <label>Name</label>
                        <input type="text" placeholder="Name" name="name" class="form-control" value="<?php echo e(old('name', $editData->name ?? '')); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-13 mb-2">
                        <label>Description</label>
                        <textarea name="description" placeholder="Description" class="form-control"><?php echo e(old('description', $editData->description ?? '')); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-3 mb-2">
                        <label>URL Key</label>
                        <input type="text" name="url_key" placeholder="URL Key" class="form-control" value="<?php echo e(old('url_key', $editData->url_key ?? '')); ?>">
                        <?php $__errorArgs = ['url_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-3 mb-2">
                        <label>Icon</label>
                        <input type="file" name="icon"  class="form-control">
                        <?php if(isset($editData->icon)): ?> <img src="<?php echo e(asset('uploads/category/'.$editData->icon)); ?>" height="40"> <?php endif; ?>
                    </div>

                    
                    <div class="col-md-3 mb-2">
                        <label>Desktop Image</label>
                        <input type="file" name="desktop_image" class="form-control">
                        <?php if(isset($editData->desktop_image)): ?> <img src="<?php echo e(asset('uploads/category/'.$editData->desktop_image)); ?>" height="40"> <?php endif; ?>
                    </div>

                    
                    <div class="col-md-3 mb-2">
                        <label>Mobile Image</label>
                        <input type="file" name="mobile_image" class="form-control">
                        <?php if(isset($editData->mobile_image)): ?> <img src="<?php echo e(asset('uploads/category/'.$editData->mobile_image)); ?>" height="40"> <?php endif; ?>
                    </div>

                    
                    <div class="col-md-12 mb-2">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="1" <?php echo e(old('status', $editData->status ?? '') == '1' ? 'selected' : ''); ?>>Active</option>
                            <option value="0" <?php echo e(old('status', $editData->status ?? '') == '0' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>

                </div>
                <div class="card-footer text-center">
                    <button class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rusoftonline/public_html/ecomm/resources/views/product_management/categories-add.blade.php ENDPATH**/ ?>