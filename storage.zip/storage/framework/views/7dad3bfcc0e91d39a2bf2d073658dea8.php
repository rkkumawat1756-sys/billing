
<?php $__env->startSection('title'); ?><?php echo e(('sizes')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('admins'); ?>
<div class="row">
    <div class="col-md-4">
        <div class="card card-orange-outline">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="mb-0"> Size </h4>
            </div>
            <form action="<?php echo e(route('size')); ?>" method="POST" id="sessionForm">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                 <input type="hidden" name="fee_id" id="fee_id">

                    <div class="row">
                        <div class="col-md-12 mb-2">
                            <label for="name">Name</label>
                            <input type="text" id="fee_name" name="name" class="form-control" placeholder="Size"
                                  >
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-2">
    <label for="status">Status</label>
    <select name="status" id="status" class="form-control">
        <option value="1">Active</option>
        <option value="0">Inactive</option>
    </select>
</div>

                    </div>
                </div>
                <div class="card-footer text-center">
                    <button type="submit" class="btn btn-secondary">Save</button>
                </div>
            </form>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card card-orange-outline">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="mb-0">Size List</h4>
            </div>
            <div class="card-body table-responsive">
                <table class="table table-bordered table-striped" id="hostelTable">
                    <thead class="table-dark">
                        <tr>
                            <th>SR</th>
                            <th> Name</th>
                             <th> Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $feePlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($plan->name); ?></td>
                            <td>
    <?php if($plan->status): ?>
        <span class="badge bg-success">Active</span>
    <?php else: ?>
        <span class="badge bg-danger">Inactive</span>
    <?php endif; ?>
</td>

                            <td>
                                <!-- Edit -->
                                <span data-id="<?php echo e($plan->id); ?>" class="fee_edit button" title="Edit">️
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="rgba(0,0,0,1)" viewBox="0 0 24 24"> <path d="M16.7574 2.99678L9.29145 10.4627L9.29886 14.7099L13.537 14.7024L21 7.23943V19.9968C21 20.5491 20.5523 20.9968 20 20.9968H4C3.44772 20.9968 3 20.5491 3 19.9968V3.99678C3 3.4445 3.44772 2.99678 4 2.99678H16.7574ZM20.4853 2.09729L21.8995 3.5115L12.7071 12.7039L11.2954 12.7064L11.2929 11.2897L20.4853 2.09729Z"></path> </svg>
</span>

 <a href="<?php echo e(route('size.delete', $plan->id)); ?>"
                                   onclick="return confirm('Are you sure you want to delete this fee plan?');"
                                   title="Delete">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="rgba(243,25,25,1)"> <path d="M4 8H20V21C20 21.5523 19.5523 22 19 22H5C4.44772 22 4 21.5523 4 21V8ZM7 5V3C7 2.44772 7.44772 2 8 2H16C16.5523 2 17 2.44772 17 3V5H22V7H2V5H7ZM9 4V5H15V4H9ZM9 12V18H11V12H9ZM13 12V18H15V12H13Z"></path> </svg>
                                    
                                  ️</a>

                                <!-- Delete -->
                              
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    var fees = <?php echo json_encode($feePlans, 15, 512) ?>;
$(document).on('click', '.fee_edit', function() {
        var id = $(this).data('id');
        // alert(id);
        if(id) {
            // find fees by id inside JS array
            var fee = fees.find(f => f.id == id);
    
            if(fee) {
                $('#fee_id').val(fee.id);
                
                $('#fee_name').val(fee.name);
                     $('#status').val(fee.status);   // status set करो यहाँ
            }
        } else {
            // reset inputs if no student selected
            $('#fee_id, #fee_name').val('');
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u362181836/domains/schoolsathi.org/public_html/r/ecom/resources/views/product_management/size.blade.php ENDPATH**/ ?>