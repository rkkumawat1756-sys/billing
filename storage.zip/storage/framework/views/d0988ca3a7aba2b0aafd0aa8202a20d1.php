
<?php $__env->startSection('title', 'User Profile'); ?>

<?php $__env->startSection('admins'); ?>
<div class="card card-orange-outline">
    <div class="card-header">
        <h4>User Profile</h4>
    </div>

    <div class="card-body">
        <!-- Nav tabs -->
        <ul class="nav nav-tabs mb-3" id="userTab" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="personal-tab" data-bs-toggle="tab" href="#personal" role="tab">Personal Details</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="address-tab" data-bs-toggle="tab" href="#address" role="tab">Delivery Address</a>
            </li>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
            <!-- Personal Details -->
            <div class="tab-pane fade show active" id="personal" role="tabpanel">
                <div class="row mb-3">
                    <div class="col-md-3">
                        <?php if($user->photo && file_exists(public_path($user->photo))): ?>
                            <img src="<?php echo e(asset($user->photo)); ?>" alt="User Photo" class="img-thumbnail w-100">
                        <?php else: ?>
                            <img src="https://img.freepik.com/free-vector/illustration-gallery-icon_53876-27002.jpg" class="img-thumbnail w-100" alt="No Photo">
                        <?php endif; ?>
                    </div>
                    <div class="col-md-9">
                        <table class="table table-bordered">
                            <tr><th>Full Name</th><td><?php echo e($user->full_name); ?></td></tr>
                            <tr><th>User Name</th><td><?php echo e($user->user_name); ?></td></tr>
                            <tr><th>Number</th><td><?php echo e($user->mobile); ?></td></tr>
                            <tr><th>Email</th><td><?php echo e($user->email); ?></td></tr>
                            <tr><th>Address</th><td><?php echo e($user->address); ?></td></tr>
                            <tr><th>Role</th><td><?php echo e($user->role->name ?? 'N/A'); ?></td></tr>
                            <tr>
                                <th>Status</th>
                                <td>
                                    <?php if($user->status): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Delivery Address -->
            <div class="tab-pane fade" id="address" role="tabpanel">
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $user->deliveryAddresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-6 mb-3">
                            <div class="card shadow-sm border 
                                <?php echo e($address->status ? 'border-primary' : 'border-danger'); ?>">
                                <div class="card-header d-flex justify-content-between align-items-center bg-light text-dark">
                                    <strong>Address #<?php echo e($key + 1); ?></strong>
                                    <div class="form-check form-switch mt-3">
                                        <input class="form-check-input status-switch" type="checkbox" id="statusSwitch<?php echo e($address->id); ?>" data-id="<?php echo e($address->id); ?>" <?php echo e($address->status ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="statusSwitch<?php echo e($address->id); ?>">
                                            <?php echo e($address->status ? 'Active' : 'Inactive'); ?>

                                        </label>
                                    </div>
                                </div>
                                <div class="card-body address-details">
                                    <table class="table table-sm">
                                        <tr><th>House No./Building</th><td><?php echo e($address->house_no); ?></td></tr>
                                        <tr><th>Area / Colony</th><td><?php echo e($address->road_area_colony); ?></td></tr>
                                        <tr><th>City</th><td><?php echo e($address->city); ?></td></tr>
                                        <tr><th>State</th><td><?php echo e($address->state); ?></td></tr>
                                        <tr><th>Pincode</th><td><?php echo e($address->pincode); ?></td></tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-muted text-center">No delivery addresses found.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap Toast Container -->
<div class="position-fixed top-0 end-0 p-3" style="z-index: 1100;">
    <div id="statusToast" class="toast align-items-center text-white bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body" id="toastBody">
                Status updated successfully.
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('demo'); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Toggle details button (if you have)
        const toggleButtons = document.querySelectorAll('.toggle-btn');
        toggleButtons.forEach(btn => {
            btn.addEventListener('click', function () {
                const details = this.closest('.card').querySelector('.address-details');
                details.classList.toggle('d-none');
            });
        });

        // AJAX toggle status switch
        const switches = document.querySelectorAll('.status-switch');
        switches.forEach(sw => {
            sw.addEventListener('change', function () {
                const addressId = this.dataset.id;
                const status = this.checked ? 1 : 0;

                fetch('<?php echo e(url('/delivery-addresses')); ?>/' + addressId + '/toggle-status', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: JSON.stringify({ status: status })
                })
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        // Update label text
                        const label = document.querySelector(`label[for="statusSwitch${addressId}"]`);
                        if (label) {
                            label.textContent = status ? 'Active' : 'Inactive';
                        }

                        // Update card border color live
                        const card = document.querySelector(`#statusSwitch${addressId}`).closest('.card');
                        if(card){
                            if(status){
                                card.classList.remove('border-danger');
                                card.classList.add('border-primary');
                            } else {
                                card.classList.remove('border-primary');
                                card.classList.add('border-danger');
                            }
                        }

                        // Show toast
                        const toastEl = document.getElementById('statusToast');
                        const toastBody = document.getElementById('toastBody');
                        toastBody.textContent = data.message || 'Delivery address status updated successfully.';

                        const bsToast = new bootstrap.Toast(toastEl);
                        bsToast.show();
                    } else {
                        alert('Failed to update status');
                    }
                })
                .catch(() => alert('Error updating status'));
            });
        });
    });
</script>

<style>
    .card .card-header {
        font-weight: 500;
    }
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rusoftonline/public_html/ecomm/resources/views/user/profile.blade.php ENDPATH**/ ?>