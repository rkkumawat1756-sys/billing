


<?php $__env->startSection('title'); ?><?php echo e(('Roles')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('admins'); ?>
    <div class="card card-orange-outline">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Role</h4>
            <div class="d-flex gap-2">
                <a class="btn btn-primary" href="<?php echo e(url('roles')); ?>"><i class="fa fa-list"></i> Role List</a>
            </div>
        </div>
             <form method="POST"    action="<?php echo e(isset($role) ? route('role.update', $role->id) : route('role.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label>Role Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($role->name ?? ''); ?>">
            </div>
        </div>
        <h5>Permissions</h5>
        
<div class="list-group col nested-sortable p-0" id="nested-demo">
    <?php $__currentLoopData = $sidebars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="list-group-item nested-1">
            <div class="form-check">
                <input type="checkbox" class="form-check-input toggle-list" 
                       data-target="child-<?php echo e($sidebar['id']); ?>" 
                       id="sidebar-<?php echo e($sidebar['id']); ?>" 
                      name="permissions[]" value="<?php echo e($sidebar['id']); ?> " <?php echo e(in_array($sidebar['id'], $assigned) ? 'checked' : ''); ?> >

                <label class="form-check-label" for="sidebar-<?php echo e($sidebar['id']); ?>">
                    <?php if(!empty($sidebar['children'])): ?>
                        <i class="fa fa-folder-open text-warning"></i>
                    <?php else: ?>
                        <i class="fa fa-file text-secondary"></i>
                    <?php endif; ?>
                    <?php echo e($sidebar['name']); ?>

                </label>
            </div>

            
            <?php if(!empty($sidebar['children'])): ?>
                <div class="list-group nested-sortable ms-4 mt-2 d-none child-<?php echo e($sidebar['id']); ?>">
                    <?php $__currentLoopData = $sidebar['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item nested-2">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input toggle-list" 
                                       data-target="subchild-<?php echo e($child['id']); ?>" 
                                       id="sidebar-<?php echo e($child['id']); ?>" 
                                      name="permissions[]" value="<?php echo e($child['id']); ?>" <?php echo e(in_array($child['id'], $assigned) ? 'checked' : ''); ?>>

                                <label class="form-check-label" for="sidebar-<?php echo e($child['id']); ?>">
                                    <?php if(!empty($child['children'])): ?>
                                        <i class="fa fa-folder-open text-warning"></i>
                                    <?php else: ?>
                                        <i class="fa fa-file text-secondary"></i>
                                    <?php endif; ?>
                                    <?php echo e($child['name']); ?>

                                </label>
                            </div>

                            
                            <?php if(!empty($child['children'])): ?>
                                <div class="list-group nested-sortable ms-4 mt-2 d-none subchild-<?php echo e($child['id']); ?>">
                                    <?php $__currentLoopData = $child['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="list-group-item nested-3">
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input toggle-perms" 
                                                       data-target="perm-<?php echo e($subchild['id']); ?>" 
                                                       id="sidebar-<?php echo e($subchild['id']); ?>" 
                                                     name="permissions[]" value="<?php echo e($subchild['id']); ?>" <?php echo e(in_array($subchild['id'], $assigned) ? 'checked' : ''); ?>>

                                                <label class="form-check-label" for="sidebar-<?php echo e($subchild['id']); ?>">
                                                    <?php if(!empty($subchild['children'])): ?>
                                                        <i class="fa fa-folder-open text-warning"></i>
                                                    <?php else: ?>
                                                        <i class="fa fa-file text-secondary"></i>
                                                    <?php endif; ?>
                                                    <?php echo e($subchild['name']); ?>

                                                </label>
                                            </div>

                                            
                                            <!--<div class="row ms-4 mt-2 d-none perm-<?php echo e($subchild['id']); ?>">-->
                                            <!--    <?php $__currentLoopData = ['add', 'edit', 'delete', 'view']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
                                            <!--        <div class="col-md-2">-->
                                            <!--            <div class="form-check">-->
                                            <!--                <input type="checkbox" -->
                                            <!--                       name="actions[<?php echo e($subchild['id']); ?>][<?php echo e($action); ?>]" -->
                                            <!--                       value="1" -->
                                            <!--                       id="action-<?php echo e($subchild['id']); ?>-<?php echo e($action); ?>" -->
                                            <!--                       class="form-check-input">-->
                                            <!--                <label for="action-<?php echo e($subchild['id']); ?>-<?php echo e($action); ?>" -->
                                            <!--                       class="form-check-label"><?php echo e(ucfirst($action)); ?></label>-->
                                            <!--            </div>-->
                                            <!--        </div>-->
                                            <!--    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                                            <!--</div>-->
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


    </div>

    <div class="card-footer text-center">
       <?php if(isset($role)): ?>
    <button type="submit" class="btn btn-warning">Update</button>
<?php else: ?>
    <button type="submit" class="btn btn-primary">Submit</button>
<?php endif; ?>

    </div>
</form>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('demo'); ?>
<script>
document.addEventListener("DOMContentLoaded", function () {
    // Show child/subchild when their parent is checked
    document.querySelectorAll(".toggle-list").forEach(function (checkbox) {
        checkbox.addEventListener("change", function () {
            let targetClass = this.dataset.target;
            let target = document.querySelector("." + targetClass);
            
            if (target) {
                if (this.checked) {
                    target.classList.remove("d-none");
                } else {
                    target.classList.add("d-none");
                    target.querySelectorAll("input[type='checkbox']").forEach(cb => cb.checked = false);
                }
            }
        });
    });

    // ✅ AUTO-OPEN based on checked items when editing
    document.querySelectorAll("input[type='checkbox']:checked").forEach(function (checkbox) {
        let current = checkbox;
        while (current && current.closest(".list-group-item")) {
            let parent = current.closest(".list-group-item").parentElement;

            if (parent.classList.contains('d-none')) {
                parent.classList.remove('d-none');
            }

            current = parent.closest(".list-group-item")?.querySelector("input[type='checkbox']");
        }
    });
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u362181836/domains/schoolsathi.org/public_html/r/ecom/resources/views/role/add.blade.php ENDPATH**/ ?>