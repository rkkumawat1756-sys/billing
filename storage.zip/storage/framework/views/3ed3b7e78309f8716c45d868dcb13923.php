
<?php $__env->startSection('title'); ?><?php echo e('Order List'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('admins'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card card-orange-outline">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4>Order List</h4>
            </div>

            <div class="card-body table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>SR</th>
                            <th>Customer Name</th>
                            <th>Order Date</th>
                            <th>Total Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <tr data-bs-toggle="collapse" data-bs-target="#order1" class="cursor-pointer">
                            <td>1</td>
                            <td><a href="javascript:void(0)">Rohit Sharma</a></td>
                            <td>2025-10-01</td>
                            <td>₹ 1286</td>
                            <td><span class="badge bg-success">Delivered</span></td>
                        </tr>

                        
                        <tr id="order1" class="collapse">
                            <td colspan="5">
                                <strong>🛒 Order Items:</strong>
                                <table class="table table-sm table-bordered mt-2">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Product</th>
                                              <th>Brand</th>
                                            <th>Type</th>
                                            <th>Size</th>
                                            <th>Color</th>
                                            <th>Image</th>
                                            <th>Qty</th>
                                            <th>Price</th>
                                            <th>Discount</th>
                                            <th>Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>T-Shirt</td>
                                                                                        <td>Apple</td>

                                            <td>Cotton</td>
                                            <td>M</td>
                                            <td>Blue</td>
                                            <td>
                                                <img src="<?php echo e(asset('uploads/1758976939_1.webp')); ?>" width="50">
                                            </td>
                                            <td>2</td>
                                            <td>₹ 343.00</td>
                                            <td>₹ 34.00</td>
                                            <td>₹ 686.00</td>
                                        </tr>
                                        <tr>
                                            <td>Jeans</td>
                                            <td>Denim</td>
                                            <td>32</td>
                                            <td>Black</td>
                                            <td>
                                                <img src="<?php echo e(asset('uploads/1759294637_0.jpg')); ?>" width="50">
                                            </td>
                                            <td>1</td>
                                            <td>₹ 600.00</td>
                                            <td>-</td>
                                            <td>₹ 600.00</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>

                        
                        <tr data-bs-toggle="collapse" data-bs-target="#order2" class="cursor-pointer">
                            <td>2</td>
                            <td><a href="javascript:void(0)">Admin User</a></td>
                            <td>2025-09-30</td>
                            <td>₹ 800</td>
                            <td><span class="badge bg-warning">Pending</span></td>
                        </tr>

                        <tr id="order2" class="collapse">
                            <td colspan="5">
                                <strong>🛒 Order Items:</strong>
                                <table class="table table-sm table-bordered mt-2">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Product</th>
                                            <th>Brand</th>
                                            <th>Type</th>
                                            <th>Size</th>
                                            <th>Color</th>
                                            <th>Image</th>
                                            <th>Qty</th>
                                            <th>Price</th>
                                            <th>Discount</th>
                                            <th>Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Mobile Cover</td>
                                            <td>Apple</td>
                                             <td>Apple</td>
                                            <td>Universal</td>
                                            <td>Black</td>
                                            <td>
                                                <img src="<?php echo e(asset('uploads/cover.jpg')); ?>" width="50">
                                            </td>
                                            <td>1</td>
                                            <td>₹ 200</td>
                                            <td>₹ 20</td>
                                            <td>₹ 180</td>
                                        </tr>
                                        <tr>
                                            <td>Headphones</td>
                                                                                        <td>Apple</td>

                                            <td>Wired</td>
                                            <td>-</td>
                                            <td>Black</td>
                                            <td>
                                                <img src="<?php echo e(asset('uploads/headphones.jpg')); ?>" width="50">
                                            </td>
                                            <td>1</td>
                                            <td>₹ 600</td>
                                            <td>₹ 0</td>
                                            <td>₹ 600</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>

                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u362181836/domains/schoolsathi.org/public_html/r/ecom/resources/views/order_management/order_list.blade.php ENDPATH**/ ?>