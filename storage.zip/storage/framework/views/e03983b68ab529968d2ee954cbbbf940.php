

<?php $__env->startSection('title'); ?>
    <?php echo e(isset($editData) ? 'Edit Product' : 'Add Product'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admins'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card card-orange-outline">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4><?php echo e(isset($editData) ? 'Edit Product' : 'Create Product'); ?></h4>
                <a href="<?php echo e(route('products')); ?>" class="btn btn-secondary">Product List</a>
            </div>

            <form action="<?php echo e(isset($editData) ? route('product.edit', $editData->id) : route('product.add')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body row">

                    
                    <div class="col-md-6 mb-2">
                        <label>Product Name</label>
                        <input type="text" name="name" class="form-control" 
                               value="<?php echo e(old('name', $editData->name ?? '')); ?>" placeholder="Product Name">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-3 mb-2">
                        <label>Category</label>
                        <select name="category_id" id="category_id" class="form-control">
                            <option value="">Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>" 
                                    <?php echo e(old('category_id', $editData->category_id ?? '') == $cat->id ? 'selected' : ''); ?>>
                                    <?php echo e($cat->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-3 mb-2">
                        <label>Subcategory</label>
                        <select name="subcategory_id" id="subcategory_id" class="form-control">
                            <option value="">Select Subcategory</option>
                            <?php if(isset($editData) && $editData->subcategory_id): ?>
                                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($subcat->category_id == ($editData->category_id ?? '')): ?>
                                        <option value="<?php echo e($subcat->id); ?>" 
                                            <?php echo e(old('subcategory_id', $editData->subcategory_id) == $subcat->id ? 'selected' : ''); ?>>
                                            <?php echo e($subcat->name); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-3 mb-2">
                        <label>Brand</label>
                        <select name="brand_id" class="form-control">
                            <option value="">Select Brand</option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->id); ?>" 
                                    <?php echo e(old('brand_id', $editData->brand_id ?? '') == $brand->id ? 'selected' : ''); ?>>
                                    <?php echo e($brand->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-3 mb-2">
                        <label>Type</label>
                        <input type="text" name="type" class="form-control" 
                               value="<?php echo e(old('type', $editData->type ?? '')); ?>" placeholder="e.g. T-Shirt">
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-3 mb-2">
                        <label>Price</label>
                        <input type="number" name="price" class="form-control" 
                               value="<?php echo e(old('price', $editData->price ?? '')); ?>" placeholder="Product Price">
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-3 mb-2">
                        <label>Discount Price</label>
                        <input type="number" name="discount_price" class="form-control" 
                               value="<?php echo e(old('discount_price', $editData->discount_price ?? '')); ?>" placeholder="Discount Price">
                        <?php $__errorArgs = ['discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-12 mb-2">
                        <label>Description</label>
                        <textarea name="description" class="form-control" rows="10"><?php echo e(old('description', $editData->description ?? '')); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-12 mb-3">
                        <label>Product Variations (Size, Color, Image)</label>
                        <div id="variation-wrapper">

                            
                            <?php if(isset($editData) && $editData->variations->count()): ?>
                                <?php $__currentLoopData = $editData->variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex mb-2 variation-row">
                                    <input type="hidden" name="existing_variation_ids[]" value="<?php echo e($variation->id); ?>">
                                    <input type="hidden" name="existing_old_images[]" value="<?php echo e($variation->image); ?>">
                                    <div class="col-md-3 px-1">
                                        <select name="existing_size_ids[]" class="form-control">
                                            <option value="">Select Size</option>
                                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($size->id); ?>" <?php echo e($variation->size_id == $size->id ? 'selected' : ''); ?>>
                                                    <?php echo e($size->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-3 px-1">
                                        <select name="existing_color_ids[]" class="form-control">
                                            <option value="">Select Color</option>
                                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($color->id); ?>" <?php echo e($variation->color_id == $color->id ? 'selected' : ''); ?>>
                                                    <?php echo e($color->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-4 px-1">
                                        <input type="file" name="existing_product_images[]" class="form-control">
                                        <?php if($variation->image): ?>
                                            <img src="<?php echo e(asset('uploads/product_variations/' . $variation->image)); ?>" alt="Variation Image" style="max-height: 50px; margin-top: 5px;">
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-md-2 px-1 d-flex align-items-center">
                                        <button type="button" class="btn btn-danger btn-remove-variation">Remove</button>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            
                            <div class="d-flex mb-2 variation-row">
                                <div class="col-md-3 px-1">
                                    <select name="size_ids[]" class="form-control">
                                        <option value="">Select Size</option>
                                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($size->id); ?>"><?php echo e($size->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-3 px-1">
                                    <select name="color_ids[]" class="form-control">
                                        <option value="">Select Color</option>
                                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-4 px-1">
                                    <input type="file" name="product_images[]" class="form-control">
                                </div>

                                <div class="col-md-2 px-1 d-flex align-items-center">
                                    <button type="button" class="btn btn-success btn-add-variation">Add More</button>
                                </div>
                            </div>

                        </div>
                    </div>

                    
                    <div class="col-md-3 mb-2">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="1" <?php echo e(old('status', $editData->status ?? '') == 1 ? 'selected' : ''); ?>>Active</option>
                            <option value="0" <?php echo e(old('status', $editData->status ?? '') == 0 ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <div class="card-footer text-center">
                    <button class="btn btn-primary"><?php echo e(isset($editData) ? 'Update Product' : 'Save Product'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('demo'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // Category -> Subcategory AJAX dynamic loading
    const categorySelect = document.getElementById('category_id');
    const subcategorySelect = document.getElementById('subcategory_id');

    categorySelect.addEventListener('change', function () {
        const categoryId = this.value;

        if (!categoryId) {
            subcategorySelect.innerHTML = '<option value="">Select Subcategory</option>';
            return;
        }

        fetch("<?php echo e(url('get-subcategories')); ?>/" + categoryId)
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                let options = '<option value="">Select Subcategory</option>';
                data.forEach(subcat => {
                    options += `<option value="${subcat.id}">${subcat.name}</option>`;
                });
                subcategorySelect.innerHTML = options;
            })
            .catch(error => {
                console.error('Error fetching subcategories:', error);
                alert('Unable to fetch subcategories.');
            });
    });

    // Variation Add / Remove Buttons functionality
    document.getElementById('variation-wrapper').addEventListener('click', function(e) {
        if (e.target.classList.contains('btn-add-variation')) {
            e.preventDefault();
            const newRow = e.target.closest('.variation-row').cloneNode(true);

            // Clear inputs/selects in cloned row
            newRow.querySelectorAll('input, select').forEach(el => {
                if (el.type === 'file') {
                    el.value = null;
                } else if (el.tagName === 'SELECT') {
                    el.selectedIndex = 0;
                } else {
                    el.value = '';
                }
            });

            // Change button in cloned row to Remove button
            const btn = newRow.querySelector('.btn-add-variation');
            btn.classList.remove('btn-success', 'btn-add-variation');
            btn.classList.add('btn-danger', 'btn-remove-variation');
            btn.textContent = 'Remove';

            this.appendChild(newRow);
        }

        if (e.target.classList.contains('btn-remove-variation')) {
            e.preventDefault();

            const row = e.target.closest('.variation-row');

            // Check if this row has an existing variation id hidden input
            const variationIdInput = row.querySelector('input[name="existing_variation_ids[]"]');
            if (variationIdInput && variationIdInput.value) {
                // Confirm delete
                if (!confirm('Are you sure you want to delete this variation?')) {
                    return;
                }

                const variationId = variationIdInput.value;

              fetch(`product-variation/${variationId}`, {
    method: 'DELETE',
    headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }
})
                .then(response => {
                    if (!response.ok) throw new Error('Failed to delete');
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        row.remove();
                        alert(data.message);
                    } else {
                        alert('Error deleting variation');
                    }
                })
                .catch(error => {
                    console.error(error);
                    alert('Error deleting variation');
                });
            } else {
                // Just remove the new unsaved row from UI
                row.remove();
            }
        }
    });

    // CKEditor for description
    ClassicEditor.create(document.querySelector('textarea[name=description]'))
        .catch(error => console.error(error));
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rusoftonline/public_html/ecomm/resources/views/product_management/product_edit.blade.php ENDPATH**/ ?>